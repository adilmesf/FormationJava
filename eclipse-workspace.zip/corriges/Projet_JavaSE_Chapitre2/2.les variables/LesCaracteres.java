public class LesCaracteres {
	public static void main(String[] args) {
		char caractereC = 'c';
		char euro1 = '€';
		char euro2 = '\u20AC';
		
		System.out.println(caractereC);
		System.out.println(euro1);
		System.out.println(euro2);
	}
}
