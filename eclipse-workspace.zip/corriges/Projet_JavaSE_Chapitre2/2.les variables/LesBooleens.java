
public class LesBooleens {

	public static void main(String[] args) {
		boolean disponible, modifiable;
		disponible=true;
		modifiable=false;
	}

}
