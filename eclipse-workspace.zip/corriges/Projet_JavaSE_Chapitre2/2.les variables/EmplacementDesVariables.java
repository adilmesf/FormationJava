public class EmplacementDesVariables 
{
	//VARIABLES D'INSTANCES
	//VARIABLES DE CLASSE
	public void uneMethode(/*PARAMETRES*/) 
	{
		//VARIABLES LOCALES
	}
}