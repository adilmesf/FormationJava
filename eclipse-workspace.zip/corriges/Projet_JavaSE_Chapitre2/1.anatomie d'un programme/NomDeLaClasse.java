public class NomDeLaClasse 
{
	//LE CODE DE VOTRE PROGRAMME
	public static void main(String[] args) 
	{
		//LE CODE DE VOTRE PROGRAMME
	}
	//LE CODE DE VOTRE PROGRAMME
}
