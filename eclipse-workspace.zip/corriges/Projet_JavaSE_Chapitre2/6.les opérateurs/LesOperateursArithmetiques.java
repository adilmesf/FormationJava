
public class LesOperateursArithmetiques {

	public static void main(String[] args) {
		System.out.println("25/3 = " + (25/3));
		System.out.println("25.0/3 = " + (25.0/3));
		System.out.println("25.0F/3 = " + (25.0F/3));
		System.out.println("25%3 = " + (25%3));
	}

}
