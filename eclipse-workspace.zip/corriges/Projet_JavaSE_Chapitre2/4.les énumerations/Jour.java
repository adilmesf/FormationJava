
public enum Jour {
    DIMANCHE, 
    LUNDI, 
    MARDI, 
    MERCREDI, 
    JEUDI, 
    VENDREDI, 
    SAMEDI 
}
