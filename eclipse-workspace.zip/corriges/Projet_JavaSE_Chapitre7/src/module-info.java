/**
 * 
 */
/**
 * @author java
 *
 */
module ProjetJavaSE_Chapitre7 {
	requires java.sql;
}



