/**
 * 
 */
/**
 * @author java
 *
 */
module Projet_JavaSE_Chapitre3_Modules {
	requires java.sql;
	exports fr.eni.editions.api;
}