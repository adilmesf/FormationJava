package fr.eni.editions.tests;

//L'utilisation de l'interface Connection nécessite la déclaration du module java.sql dans le fichier module-info.java.
import java.sql.Connection;

public class TestSQL {

	public static void main(String[] args) {
		Connection cnx;
		String uneChaine = "Bonjour";
	}

}






















