package fr.eni.editions.api;

public interface Persistence {
	public void ajouter(Object o);
	public void supprimer(Object o);
	//...
}
