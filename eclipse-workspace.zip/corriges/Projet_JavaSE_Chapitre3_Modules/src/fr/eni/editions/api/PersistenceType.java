package fr.eni.editions.api;

public enum PersistenceType {
	SQL,
	NoSQL
}
