/**
 * 
 */
/**
 * @author java
 *
 */
module Projet_JavaSE_Chapitre5 {
	requires java.desktop;
}