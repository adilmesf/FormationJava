/**
 * Le nom de la classe doit correspondre au nom du fichier.
 * @author java
 *
 */
public class PremierProgramme {

	/**
	 * La méthode main est le point d'entrée d'un programme.
	 * La signature de cette méthode ne peut pas être modifiée
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("Bonjour tout le monde");

	}

}
