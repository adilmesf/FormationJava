package fr.eni.editions.lambdas;

@FunctionalInterface
public interface MonInterfaceFonctionnelle {
	int maMethode(int unParametre);
}
