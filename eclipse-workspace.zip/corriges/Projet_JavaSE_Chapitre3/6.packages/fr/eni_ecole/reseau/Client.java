package fr.eni_ecole.reseau;

public class Client {

}
