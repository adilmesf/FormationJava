package fr.eni_ecole.test;

import fr.eni_ecole.compta.Client;

public class TestClientPackage {

	public static void main(String[] args) {
		Client clientCompta = new Client();
		fr.eni_ecole.reseau.Client clientReseau = new fr.eni_ecole.reseau.Client(); 
	}
}
