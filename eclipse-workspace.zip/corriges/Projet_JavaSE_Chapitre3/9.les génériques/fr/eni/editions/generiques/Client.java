package fr.eni.editions.generiques;

import java.time.LocalDate;

public class Client extends Personne {

	public Client() {
		super();
	}

	public Client(String n, String p, LocalDate d) {
		super(n, p, d);
	}

}
