package fr.eni.editions.heritage;

public class LignesDeCommande implements Cloneable 
{ 
     public Object clone() throws CloneNotSupportedException 
     { 
          return super.clone(); 
     } 
}
