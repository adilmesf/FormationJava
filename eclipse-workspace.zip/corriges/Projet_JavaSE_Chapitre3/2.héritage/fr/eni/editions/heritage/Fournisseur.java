package fr.eni.editions.heritage;

public non-sealed class Fournisseur extends Personne {

}
