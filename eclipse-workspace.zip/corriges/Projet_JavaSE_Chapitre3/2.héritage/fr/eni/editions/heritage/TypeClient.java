package fr.eni.editions.heritage;

public enum TypeClient {
	PARTICULIER,
	ENTREPRISE,
	ADMINISTRATION;
}
