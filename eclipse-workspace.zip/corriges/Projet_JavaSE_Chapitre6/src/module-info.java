/**
 * 
 */
/**
 * @author java
 *
 */
module ProjetJavaSE_Chapitre6 {
	requires java.sql;
}