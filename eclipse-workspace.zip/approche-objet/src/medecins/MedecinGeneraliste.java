package medecins;

public class MedecinGeneraliste {
	private String nom;
	private String prenom;
	private String telephone;
	static int tarif;

	public MedecinGeneraliste(String nom, String prenom, String telephone) {
		this.nom = nom;
		this.prenom = prenom;
		this.telephone = telephone;
	}

	public void afficher() {
		System.out.println(this.getNom().toUpperCase() + " " + this.getPrenom());
		System.out.println(this.getTelephone());
		System.out.println(this.getTarif());
	}
	
	
	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public int getTarif() {
		return tarif;
	}

	public static void setTarif(int tarif) {
		MedecinGeneraliste.tarif = tarif;
	}

	public String getNom() {
		return nom;
	}
	
	public String getPrenom() {
		return prenom;
	}
	
	
}
