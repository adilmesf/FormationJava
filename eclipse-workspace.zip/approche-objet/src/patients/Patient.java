package patients;

import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.Locale;

public class Patient {
	private String nom;
	private String prenom;
	private String telephone;
	private char sexe;
	private long numsecu;
	private LocalDate datenaiss;
	private String commentaires;
	
	private String libSexe;
	private String libComm;
	
	
	public Patient(String nom, String prenom, String telephone, char sexe, long secu, LocalDate daten, String comm){
		this.nom = nom;
		this.prenom = prenom;
		this.telephone = telephone;
		this.sexe = sexe;
		this.numsecu = secu;
		this.datenaiss = daten;
		this.commentaires = comm;
	}
	
	public void afficher() {

		switch (this.getSexe()) {
		case 'M': libSexe = "Masculin";
				 break;
		case 'F': libSexe = "F�minin";
				 break;
		default: libSexe = "";
				 break;
		}
		
		System.out.println(this.getNom().toUpperCase() + " " + this.getPrenom());
		System.out.println("T�l�phone : " + this.getTelephone());
		System.out.println("Sexe : " + libSexe);
		System.out.println("Num�ro de s�curit� sociale : " + this.numsecu);
		System.out.println("Date de naissance : " + this.getDatenaiss().getDayOfMonth() + " " + (this.getDatenaiss().getMonth().getDisplayName(TextStyle.FULL, Locale.FRANCE).toUpperCase()) + " " + this.getDatenaiss().getYear() );
		
		if (this.getCommentaires() == null) {
			libComm = "[Aucun commentaire]";
		} else {
			libComm = this.getCommentaires();
		}
		System.out.println("Commentaires : " + libComm);
		
	}
	
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public char getSexe() {
		return sexe;
	}
	public void setSexe(char sexe) {
		this.sexe = sexe;
	}
	public long getNumsecu() {
		return numsecu;
	}
	public void setNumsecu(long numsecu) {
		this.numsecu = numsecu;
	}
	public LocalDate getDatenaiss() {
		return datenaiss;
	}
	public void setDatenaiss(LocalDate datenaiss) {
		this.datenaiss = datenaiss;
	}
	public String getCommentaires() {
		return commentaires;
	}
	public void setCommentaires(String commentaires) {
		this.commentaires = commentaires;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	
	
	
}
