package entites;

import entites2.Personne;

public class TestPersonne {

	public static void main(String[] args) {
		
		/*Personne pers1 = new Personne("Machin","Pierre");
		Personne pers2 = new Personne("Bidule","Jean");*/
		
		AdressePostale adresse1 = new AdressePostale(10,"rue de la joie","44100","Nantes");
		AdressePostale adresse2 = new AdressePostale(11,"rue de la joie","44100","Nantes");
		Personne pers1 = new Personne("Machin","Pierre",adresse1);
		Personne pers2 = new Personne("Bidule","Jean",adresse2);		
				
		pers1.AffichePersonne();
		pers2.AffichePersonne();
		
		/* Nom */
		pers1.setNom("Truc");
		pers1.AffichePersonne();

		/* Prenom */
		pers1.setPrenom("Paul");
		pers1.AffichePersonne();
		
		/* Adresse */
		
		pers1.getAdresse().setNumRue(10);
		pers1.getAdresse().setLibRue("rue des pleurs");
		pers1.getAdresse().setCodePostal("44200");
		pers1.getAdresse().setVille("Nantes");
		
		pers1.setAdresse(adresse1);
		System.out.println(pers1.getAdresse().getLibRue());
		System.out.println(pers2.getAdresse().getLibRue());
		
	}

}
