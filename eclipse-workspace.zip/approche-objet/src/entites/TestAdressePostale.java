package entites;

public class TestAdressePostale {

	public static void main(String[] args) {
		
		AdressePostale adresse1 = new AdressePostale(5, "rue de la ville", "44000", "Nantes");
		AdressePostale adresse2 = new AdressePostale(6, "rue de la ville", "44000", "Nantes");


	}

}
