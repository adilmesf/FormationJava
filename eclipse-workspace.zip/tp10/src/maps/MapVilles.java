package maps;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import listes.Ville;

public class MapVilles {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
			ArrayList<Ville> villes = new ArrayList<>(Arrays.asList (
				      new Ville("Nice",343000),
				      new Ville("Carcassonne",47800),
				      new Ville("Narbonne",53400),
				      new Ville("Lyon",484000),
				      new Ville("Foix",9700),
				      new Ville("Pau",77200),
				      new Ville("Marseille",850700),
				      new Ville("Tarbes",40600)
	));*/
		HashMap<String,Ville > mapVille = new HashMap<>();
		mapVille.put("1",new Ville("Nice",343000));
		mapVille.put("2",new Ville("Carcassonne",47800));
		mapVille.put("3",new Ville("Narbonne",53400));
		mapVille.put("4",new Ville("Lyon",484000));
		mapVille.put("5",new Ville("Foix",9700));
		mapVille.put("6",new Ville("Pau",77200));
		mapVille.put("7",new Ville("Marseille",850700));
		mapVille.put("8",new Ville("Tarbes",40600));
		
		for (Map.Entry<String, Ville> setVille : mapVille.entrySet()) {
			System.out.println(setVille.getValue().getNom() + " " + setVille.getValue().getNbHabitant());
		}
	}

}
