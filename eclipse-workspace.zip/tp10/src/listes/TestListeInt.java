package listes;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TestListeInt {

	public static void main(String[] args) {
		List<Integer> listeEntier = new ArrayList<Integer>();
		
		listeEntier.add(-1);
		listeEntier.add(5);
		listeEntier.add(7);
		listeEntier.add(3);
		listeEntier.add(-2);
		listeEntier.add(4);
		listeEntier.add(8);
		listeEntier.add(5);

		// Affichage de la liste
		System.out.println(listeEntier);
		
		// Affichage du plus grand de la liste
		System.out.println(Collections.max(listeEntier));
		
		//Supprimez le plus petit �l�ment de la liste
		listeEntier.remove(listeEntier.indexOf(Collections.min(listeEntier)));
		System.out.println(listeEntier);
		
		//Recherchez les �l�ments n�gatifs et modifiez les pour qu'ils deviennent positifis
		for (int i = 0; i <= listeEntier.size() - 1; i++) {
			if (listeEntier.get(i) < 0) {
				listeEntier.add(listeEntier.get(i) * -1);
				listeEntier.remove(i);
			}
		}
		
		// Affichage de la liste
		System.out.println(listeEntier);
		
	}
	


}
