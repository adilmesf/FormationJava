package listes;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;


public class AppelerVilles {

	@SuppressWarnings("unlikely-arg-type")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList<Ville> villes = new ArrayList<>(Arrays.asList (
							      new Ville("Nice",343000),
							      new Ville("Carcassonne",47800),
							      new Ville("Narbonne",53400),
							      new Ville("Lyon",484000),
							      new Ville("Foix",9700),
							      new Ville("Pau",77200),
							      new Ville("Marseille",850700),
							      new Ville("Tarbes",40600)
		));
	
		/* Afficher la ville qui a le plus d'habitants */
		System.out.println("Ville qui a le plus d'habitants : " +
				  villes.stream()
			      .max(Comparator.comparingInt(e -> e.getNbHabitant())) /* = Ville::getNbHabitant */
			      .orElseThrow()
			      .getNom()
				  );
		
		/* Supprimer la ville qui a le moins d'habitants */
		villes.remove(villes.remove(villes.indexOf(
				  villes.stream()
				  .min(Comparator.comparingInt(e -> e.getNbHabitant())) /* = Ville::getNbHabitant */
				  .orElseThrow()
				)));
		
		for (int i = 0; i <= villes.size() - 1; i++) {
			System.out.println(villes.get(i).getNom());
		}
					
		

	}

}
