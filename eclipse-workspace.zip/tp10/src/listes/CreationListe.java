package listes;

import java.util.ArrayList;
import java.util.List;

public class CreationListe {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> listes = new ArrayList<Integer>();
		for (Integer i = 0; i <= 99; i++) {
			listes.add(i);
		}
		System.out.println("Taille de la liste : " + listes.size());
		
	}

}
