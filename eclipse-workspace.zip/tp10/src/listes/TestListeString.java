package listes;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;


public class TestListeString {

	public static void main(String[] args) {
		
		List<String> villes = new ArrayList<String>();
		villes.add("Nice");
		villes.add("Carcassonne");
		villes.add("Narbonne");
		villes.add("Lyon");
		villes.add("Foix");
		villes.add("Pau");
		villes.add("Marseille");
		villes.add("Tarbes");
		
		// La ville qui a le plus de lettres
		System.out.println( villes
							.stream() 
							.max(Comparator.comparingInt(e -> e.length()))
							.orElse("Pas trouv�")
							);
		
		//Mettre toutes les villes en majuscule
		villes.replaceAll(String::toUpperCase);
		System.out.println(villes);						

		// La ville qui a le plus de lettres
		List<String> ville = villes.stream() 
							.filter(e -> !e.startsWith("N"))
							.collect(Collectors.toList());
		
		System.out.println(ville);
			
	}

}
