package tp1;

import java.util.Arrays;

public class tp1 {

	public static void main(String[] args) {
		
		int nb = 3;
		String[] tableau = {"toto@vif.fr","titi@wanadoo.fr","tata@vif.fr"};
		String[] tabl2   = new String[10];
		int[] tabCnt	 = new int[10];

		/* Affichage du contenu */
		for (int j = 0; j <= nb - 1; j++) {
			System.out.println(tableau[j]);
		} 	
		
		int indice = 0;
		String mail;
		String fournisseur;
	
		
		for (int k = 0; k <= nb - 1; k++) {
			
			indice = tableau[k].indexOf("@");
			mail = tableau[k];
			mail = (mail.substring(indice + 1,mail.length()));
			fournisseur = (mail.substring(0, mail.indexOf(".")));
			indice = (Arrays.asList(tabl2).indexOf(fournisseur));

			if ((Arrays.asList(tabl2).indexOf(fournisseur)) > -1) {
				tabCnt[indice] = tabCnt[indice] + 1;
				System.out.println(tabCnt[indice]);
			} else {
				for (int j = 0; j <= 10 ; j++) {
					if (tabl2[j] == null) {
						tabl2[j] = fournisseur;
						tabCnt[j] = tabCnt[j] + 1;
						break;
					}
				}
			}
			
			/* Affichage du contenu */
			for (int j = 0; j <= nb - 1; j++) {
				System.out.println(tabl2[j]);
			} 	
			for (int i = 0; i <= nb - 1; i++) {
				System.out.println(tabCnt[i]);
			} 	
			
			
		}

		
	}

}
