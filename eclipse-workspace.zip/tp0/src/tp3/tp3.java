package tp3;

import java.time.Duration;
import java.time.OffsetTime;
import java.util.Random;
import java.util.Scanner;

public class tp3 {

	public static void main(String[] args) {

		int nb = 0;
		boolean trouve = false;
		 
		Random rd  = new Random();
		nb = rd.nextInt(1000);

		Scanner scanner;
		scanner = new Scanner(System.in);
		
		OffsetTime debut = OffsetTime.now(); 
		while (trouve == false) {
			 
			 System.out.println("Veuillez saisir un chiffre");
			 int chiffre = scanner.nextInt();
			 
			 if (chiffre == nb) {
				 trouve = true;
			 } else {
				 if (chiffre < nb) {
					 System.out.println("Trop Bas !");
				 } else {
					 System.out.println("Trop Haut !");
				 }
			 }
		 }
		OffsetTime fin = OffsetTime.now();
		Duration duree = Duration.between(debut, fin);
		
		if (trouve == true){
			System.out.println("Bravo vous avez trouv� le bon nombre : " + nb + " en : " + duree.getSeconds() + " secondes ");
		}

		 scanner.close();
		 
	}

}
