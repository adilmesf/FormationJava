package tp4;

public class Tp42 extends tp4 {
	
	public void tp() {
		super.setK(5);
		System.out.println(getK());
	}
}
