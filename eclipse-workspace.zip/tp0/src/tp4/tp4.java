package tp4;

public class tp4 {
	
	static 	  int i = 0;
	protected int j = 0;
	private   int k = 0;
	
	public static void main(String[] args) {
	}

	public void retourneI() {
		System.out.println(i);
	}
	public void ajouteI(int vI) {
		i = i + vI;
	}

	public int getK() {
		return k;
	}

	public void setK(int k) {
		this.k = k;
	}
}


