package tp4;

public class Tp41 {

	public static void main(String[] args) {
		tp4 objet = new tp4();
		Tp42 obj2 = new Tp42();
		extracted(objet);
		extracted(obj2);
	}

	private static void extracted(tp4 objet) {
		objet.ajouteI(5);
		objet.retourneI();
		objet.ajouteI(4);
		objet.retourneI();
		objet.setK(5);
		System.out.println("k : " + objet.getK());
	}

}
