package tp2;

import java.util.Random;

public class tp2 {

	
	public static void main(String[] args) {
		
		 int nb = 0;
		 int nb2 = 0;
		 int nbessais = 0;
		 boolean trouve = false;
		 
		Random rd  = new Random();

		while (trouve == false) {
			nbessais++;
			nb2 = 0;
			for (int i = 1; i <= 3; i++) {
				nb = rd.nextInt(10000);
				if (nb % 2 == 0) {
					nb2++;
				} else {
					nb2 = 0;
				}
				System.out.println(nb % 2);
				if (nb2 == 2) {
					trouve = true;
				}
			}
		}
		System.out.println("Nb essais" + " " + nbessais);

	}

}
