package tp0;

import java.util.Scanner;

/* Nom en CamelCase 										 */
/* Nom du fichier identique au nom de la classe 			 */
/* Disable SpellChecking pour enlever le surlignage en jaune */
public class Bonjour
{
	static String texte = "2";
	final static String vPi = "3.14"; /* <== Constante avec mot cl� final */
	
	public static void main (String[] args)
	{
		
		int i = 0;
		while(i<10) {
			i++;
			ShowTxt2(i);
		}
		
		for (i = 0; i<= 10 ; i++) {
			ShowTxt2(i);
		}
		
		Scanner scanner;
		scanner = new Scanner(System.in);
		ShowTxt ("Veuillez saisir un chiffre");
		String chiffre = scanner.next();
		ShowTxt(chiffre);
		scanner.close();
		
		System.out.println("Hello"); /* Sortie console */
		ShowTxt("Hello 3");
		ShowTxt(CalcTxt("Hello 4"));
		System.out.println(texte.concat("1"));
		ShowTxt(vPi);
	}
	
	public static void ShowTxt (String ShowText) {
		System.out.println(ShowText);
	}
	public static void ShowTxt2 (int ShowText2) {
		System.out.println(ShowText2);
	}
	public static String CalcTxt (String ShowText) {
		return ShowText + "1";
	}

}
