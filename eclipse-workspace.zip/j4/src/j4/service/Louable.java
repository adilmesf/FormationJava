package j4.service;

public interface Louable {

	Boolean isLoue();

	void setLoue(Boolean b);

}
