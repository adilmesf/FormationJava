package j4.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import j4.bo.Cycle;
import j4.bo.Velo;
import j4.exception.VeloDejaLoueBusinessException;
import j4.tri.*;

public class LocationService{

	private static List<Louable> stock;

	static {
		stock = new ArrayList<Louable>();
	}

	public static void ajouter(Louable cycle) {
		stock.add(cycle);
	}
	
	public static List<Cycle> filtreCycle(){
		List<Cycle> cycles = new ArrayList<Cycle>();
		for (Louable louable : stock) {
			if (louable instanceof Cycle) {
				cycles.add((Cycle) louable);
			}
		}
		return cycles;
	}

	@SuppressWarnings("unchecked")
	public static <T> List<T> filtrer(Class<T> classz){
		List<T> cycles = new ArrayList<T>();
		for (Louable louable : stock) {
			if (classz.isInstance(louable)) {
				cycles.add((T) louable);
			}
		}
		return cycles;
	}
	
	/*public static Cycle getCycleDispo() {
		List<Cycle> cycles = filtrer(Cycle.class);
		/*List<Cycle> cyclesdispo = new ArrayList<Cycle>();
		
		for (Cycle cycle : cycles) {
			if (!cycle.isLoue()) {
				cyclesdispo.add(cycle);
			}
		}
		
		return Collections.min(cyclesdispo, new TriParTarifs());
	}*/


	
	public static Cycle getCycleDispo() {
		List<Cycle> cycles = filtrer(Cycle.class);

		List<Cycle> cyclesdispo = cycles
								.stream() 
								.sorted(Comparator.comparing(Cycle::getTarifLocationHeure))
								.filter(e -> !e.isLoue())
								.collect(Collectors.toList());

		return Collections.min(cyclesdispo, new TriParTarifs());
	}

	public static void ajouterTout(List<? extends Louable> cycles) {
		stock.addAll(cycles);
	}

	public synchronized static void louer(Louable articleLouable) throws VeloDejaLoueBusinessException {
		if (articleLouable.isLoue()) {
			throw new VeloDejaLoueBusinessException("Cycle d�j� lou�");
		}

		articleLouable.setLoue(true);
	}

	public synchronized static void liberer(Louable articleLouable) throws Exception {
		if (!articleLouable.isLoue()) {
			throw new Exception("Ce cycle n'est pas en cours de location");
		}

		articleLouable.setLoue(false);
	}

	public static List<Louable> getArticleDisponible() {
		List<Louable> louables = new ArrayList<>();
		for (Louable louable : stock) {
			if (louable.isLoue() == false) {
				louables.add(louable);
			}
		}
		return louables;
	}

	public static List<Louable> getVeloDisponible() {
		List<Louable> louables = new ArrayList<>();
		for (Louable louable : stock) {
			if (louable instanceof Velo && louable.isLoue() == false) {
				louables.add(louable);
			}
		}
		return louables;
	}

	public static List<Louable> getLouableDisponible(Class<? extends Louable> clazz) {
		List<Louable> louables = new ArrayList<>();
		for (Louable louable : stock) {
			if (louable.getClass() == clazz && louable.isLoue() == false) {
				louables.add(louable);
			}
		}
		return louables;
	}
	





	/******
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 */

}
