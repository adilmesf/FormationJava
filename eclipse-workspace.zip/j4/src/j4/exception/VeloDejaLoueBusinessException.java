package j4.exception;

public class VeloDejaLoueBusinessException extends Exception {

	public VeloDejaLoueBusinessException(String message) {
		super(message);
	}
}
