package j4.bo;

import java.time.LocalDate;

import j4.service.Louable;

public abstract class Cycle implements Louable, Comparable<Cycle> {
	private LocalDate dateAchat;
	private String marque;
	private String modele;
	private boolean isLoue = false;

	public Cycle() {

	}

	/**
	 * Constructeur de cycle
	 * 
	 * @param dateAchat date d'achat du cycle
	 * @param marque    marque du cycle
	 * @param modele    mod�le du cycle
	 */
	public Cycle(LocalDate dateAchat, String marque, String modele) {
		this.dateAchat = dateAchat;
		this.marque = marque;
		this.modele = modele;
	}

	/**
	 * Calcule l'�ge du cycle en fonction de sa date d'achat
	 * 
	 * @return l'�ge du cycle
	 */
	public int age() {
		return dateAchat.until(LocalDate.now()).getYears();
	}

	/**
	 * Indique le tarif de location pour une heure
	 * 
	 * @return le tarif de location pour une heure
	 */
	public Double getTarifLocationHeure() {
		// TODO Auto-generated method stub
		return null;
	}

	public LocalDate getDateAchat() {
		return dateAchat;
	}

	public void setDateAchat(LocalDate dateAchat) {
		this.dateAchat = dateAchat;
	}

	public String getMarque() {
		return marque;
	}

	public void setMarque(String marque) {
		this.marque = marque;
	}

	public String getModele() {
		return modele;
	}

	public void setModele(String modele) {
		this.modele = modele;
	}

	@Override
	public Boolean isLoue() {
		return isLoue;
	}

	@Override
	public void setLoue(Boolean isLoue) {
		this.isLoue = isLoue;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		int age = this.age();
		return String.format("%s %s %s (%dan%s) lou� ? %s", this.getClass().getSimpleName(), this.marque, this.modele,
				age, age > 1 ? "s" : "", isLoue());
	}
	
	@Override
	public int compareTo(Cycle c) {
		//return this.marque.compareTo(c.marque);
		return 0;
	}
}