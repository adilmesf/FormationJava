package j4.bo;

import j4.service.Louable;

public class Casque implements Louable {

	int taille;

	boolean isLoue = false;

	@Override
	public Boolean isLoue() {
		return isLoue;
	}

	@Override
	public void setLoue(Boolean b) {
		this.isLoue = b;
	}

}
