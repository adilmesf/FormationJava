package j4.tri;

import j4.bo.Cycle;
import j4.bo.Velo;
import j4.exception.VeloDejaLoueBusinessException;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import j4.service.Louable;

public class TriParMarque implements Comparator<Cycle> {
	
	@Override
	public int compare(Cycle o1, Cycle o2) {
		// TODO Auto-generated method stub
		return o1.getMarque().compareTo(o2.getMarque());
	}
}
