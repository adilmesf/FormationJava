package j4.tri;

import java.util.Comparator;

import j4.bo.Cycle;
import j4.bo.*;

public class TriParTailleMinimale  implements Comparator<Cycle> {

	@Override
	public int compare(Cycle o1, Cycle o2) {
		
		if ((o1 instanceof Gyropode) && (o2 instanceof Gyropode)) {
			Gyropode g1 = (Gyropode)o1;
			Gyropode g2 = (Gyropode)o2;
			//g.getTailleMinCm();
			return g1.getTailleMinCm().compareTo(g2.getTailleMinCm());
		}
		return 0;
	}

}
