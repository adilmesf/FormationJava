package j4.tri;

import java.util.Comparator;

import j4.bo.Cycle;

public class TriParTarifs  implements Comparator<Cycle> {

	@Override
	public int compare(Cycle o1, Cycle o2) {
		return o1.getTarifLocationHeure().compareTo(o2.getTarifLocationHeure());
	}

}
