package j4;

import java.time.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import j4.bo.Casque;
import j4.bo.Cycle;
import j4.bo.Gyropode;
import j4.bo.Gyroroue;
import j4.bo.Velo;
import j4.exception.VeloDejaLoueBusinessException;
import j4.service.LocationService;
import j4.service.Louable;
import j4.tri.*;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Location {

	/**
	 * Crée un tableau de cycles et les affiche
	 * 
	 * @param args pas nécessaire
	 * @throws Exception
	 */
	private static final Logger log = LogManager.getLogger(Location.class);
	public static void main(String[] args) throws Exception {
		log.info("Toto");
		boolean test = false;
		String resultat;

		List<Louable> jeuxdeDonnees = Arrays.asList(
				new Velo(LocalDate.of(2017, Month.JUNE, 2), "Lapierre", "speed 400", 27),
				new Velo(LocalDate.of(2018, Month.APRIL, 9), "Btwin", "riverside 900", 10),
				new Gyropode(LocalDate.of(2018, Month.JUNE, 5), "Segway", "Ninebot Elite", 40, 150),
				new Gyropode(LocalDate.of(2017, Month.MAY, 2), "Weebot", "Echo", 35, 160),
				new Gyroroue(LocalDate.of(2018, Month.MARCH, 25), "Immotion", "v8", 40),
				new Gyroroue(LocalDate.of(2018, Month.MARCH, 25), "Segway", "Ninebot One E+", 30), new Casque());

		LocationService.ajouterTout(jeuxdeDonnees); // initialsiation du stock de cycles

		System.out.println("Voici les cycles que nous proposons à la location :");
		afficherStock(jeuxdeDonnees);

		try {
			LocationService.louer(jeuxdeDonnees.get(0));
			LocationService.louer(jeuxdeDonnees.get(0));

		} catch (VeloDejaLoueBusinessException e) {
			System.out.println(e);
			throw new Exception(e);
		}

		afficherStock(jeuxdeDonnees);

		Casque casque = new Casque();
		System.out.println("casque loué ?" + casque.isLoue());
		LocationService.louer(casque);
		System.out.println("casque loué ?" + casque.isLoue());

		System.out.println("article dispo:");
		afficherStock(LocationService.getArticleDisponible());

		System.out.println("Velo.class dispo:");
		afficherStock(LocationService.getLouableDisponible(Velo.class));
	
		//Collections.sort(LocationService.filtreCycle(), Collections.reverseOrder());
		//Collections.sort(LocationService.filtreCycle());
		/*
		List<Cycle> cycles = new ArrayList<Cycle>(LocationService.filtreCycle());
		Collections.sort(cycles, new TriParMarque());
		Collections.sort(cycles, new TriParTarifs());
		Collections.sort(cycles, new TriParTarifs().reversed());
		Collections.sort(cycles, new TriParDateAchat());
		//Collections.sort(cycles, new TriParTailleMinimale());
		List<Cycle> gyro = new ArrayList<Cycle>(LocationService.filtrer(Cycle.class));
		Collections.sort(gyro, new TriParTailleMinimale());
		for (Cycle a : gyro) {
			System.out.println(a);
		}
		*/
		LocationService.louer(jeuxdeDonnees.get(0));
		System.out.println(LocationService.getCycleDispo());

	}
	/*
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 */
	//

	private static void afficherStock(List<Louable> jeuxdeDonnees) {
		for (Louable louable : jeuxdeDonnees) {
			if (louable instanceof Cycle) {
				System.out.printf("- %-95s %5.2f€/heure%n", ((Cycle) louable).toString(),
						((Cycle) louable).getTarifLocationHeure());
			} else {
				System.out.printf("- %-95s %n", louable.toString());

			}
		}
	}
}
