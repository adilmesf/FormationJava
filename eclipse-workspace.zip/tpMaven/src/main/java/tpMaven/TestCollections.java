package tpMaven;

public class TestCollections {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello 3 !");
	}

}
