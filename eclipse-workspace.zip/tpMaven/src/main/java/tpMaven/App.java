package tpMaven;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello 1 !");
		System.out.println("Hello 2 !");

	}

}
