package tpMaven;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestCollectionsTest {

	@Test
	void testMain() {
		fail("Not yet implemented");
	}

}
