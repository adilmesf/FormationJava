package j3;

public class J31 extends j3 {

	private String nom;

	public J31(String nom) {
		super(nom, "");
		this.nom = nom;
	}
	
	@Override
	public void test() {
		System.out.println(this.getNom());
	}

	public String getNom() {
		return this.nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}
	
	
}
