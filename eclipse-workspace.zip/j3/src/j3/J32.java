package j3;

public class J32 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		J31 essai = new J31("titi");
		System.out.println(essai.getNom());

	}

		

}
