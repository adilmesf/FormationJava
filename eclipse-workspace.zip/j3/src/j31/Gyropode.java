package j31;

import java.time.LocalDate;

public class Gyropode extends Cycle {

	private int autonomie;
	
	public Gyropode(String type, String marque, String modele, LocalDate dateAch, int autonomie) {
		super(type, marque, modele, dateAch);
		this.autonomie = autonomie;
		
	}

	public int getautonomie() {
		return autonomie;
	}

	public void setautonomie(int autonomie) {
		this.autonomie = autonomie;
	}

	@Override
	public double getTarifLocationHeure() {
		// TODO Auto-generated method stub
		return 0;
	}


}
