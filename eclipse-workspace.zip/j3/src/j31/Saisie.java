package j31;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Saisie {
	
	static int vI;
	static String chaine;
	static String chaine2;
	static int chaine3;
	
	
	public static void main(String[] args) {
		Cycle[] aLouer = {new Velos("Velo", "Mapierre", "speed 400", LocalDate.of(2021, 1, 1), 27),
						  new Velos("Velo", "Btwin", "riverside 900", LocalDate.of(2020, 1, 1), 27),
						  new Gyroroue("Gyroroue", "Immotion", "v8", LocalDate.of(2021, 1, 1), 40,160)};
		
		LocationService location = new LocationService();
		/*System.out.println(location.ajouterTout(aLouer));*/

		for (Cycle c : aLouer) {
			//System.out.printf("- %-95s %5.2f/heure%n", c.toString(), c.getTarifLocationHeure());
			System.out.println(c.toString());
			location.ajouter(c);
		}
		
		try {
			location.louerCycle(aLouer[0]);
			location.louerCycle(aLouer[1]);
			location.louerCycle(aLouer[2]);
			location.louerCycle(aLouer[0]);
		} catch (Exception e) {
			System.out.println(e);
		}

		Casque casque = new Casque("Decathlon","Enfant");
		try {
		location.louerCycle(casque);
		} catch (Exception e) {
			System.out.println(e);
		}
		/*Map map=new HashMap();
		
		Velos velo = new Velos("Velo", "Mapierre", "speed 400", LocalDate.of(2021, 1, 1), "4,90�", 27);
		vI = map.size();
		chaine = retourChaine(velo);
		map.put(vI++, chaine);

		Velos velo2 = new Velos("Velo", "Btwin", "riverside 900", LocalDate.of(2021, 1, 1), "4,90�", 27);
		vI = map.size();
		chaine = retourChaine((Cycle)velo2);
		map.put(vI++, chaine);

		Gyroroue gyror = new Gyroroue("Gyroroue", "Immotion", "v8", LocalDate.of(2021, 1, 1), "18,90�",40);
		vI = map.size();
		chaine = retourChaine(gyror);
		map.put(vI++, chaine);
		
	    	//Affichage des �l�ments 
		    map.keySet();
		    
		    //Traversing Map  
		    Set set=map.entrySet();//Converting to Set so that we can traverse  
		    
		    Iterator itr= set.iterator();  
		    
		    while(itr.hasNext()){  
		        //Converting to Map.Entry so that we can get key and value separately  
		        Map.Entry entry=(Map.Entry)itr.next();  
		        System.out.println(entry.getValue());  
		    }  
		    */
	    
	}
	/*
	static String retourChaine (Cycle velo) {
		switch (velo.getType()){
		case "Velo":  chaine3 = ((Velos) velo).getNbVitesse();
		break;
		case "Gyroroue": chaine3 = ((Gyroroue) velo).getautonomie();
		break;
		case "Gyropode": chaine3 = ((Gyropode) velo).getautonomie();
		break;
		}
		chaine2 = velo.getType() + " " + velo.getMarque() + " " + velo.getModele() + " " + velo.getDateAch() + " " + chaine3 + " " + velo.getTarifs();
		return chaine2;
	}*/

}
