package j31;

public class Casque implements Louable {
	
	private String marque;
	private String taille; /* Enfants/Adulte */
	private boolean loue;
	
	public Casque(String marque, String taille) {
		
		this.marque = marque;
		this.taille = taille;
		this.loue = false;
	}
	
	public String getMarque() {
		return marque;
	}
	public void setMarque(String marque) {
		this.marque = marque;
	}
	public String getTaille() {
		return taille;
	}
	public void setTaille(String taille) {
		this.taille = taille;
	}

	@Override
	public boolean isLoue() {
		// TODO Auto-generated method stub
		return this.loue;
	}

	@Override
	public void setLoue(boolean b) {
		// TODO Auto-generated method stub
		this.loue = b;
	}
	
	
}
