package j31;

import java.time.LocalDate;

public class Velos extends Cycle {

	private int nbVitesse;
	
	public Velos(String type, String marque, String modele, LocalDate dateAch, int nbVitesse) {
		super(type, marque, modele, dateAch);
		this.nbVitesse = nbVitesse;
		
	}

	public int getNbVitesse() {
		return nbVitesse;
	}
	
	public void setNbVitesse(int nbVitesse) {
		this.nbVitesse = nbVitesse;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @see fr.eni.ecole.location.Cycle#getTarifLocationHeure()
	 */
	@Override
	public double getTarifLocationHeure() {
		return 14.9;
	}
	
	@Override
	public String toString() {
		return String.format("%s %d vitesse%s", super.toString(), this.nbVitesse, this.nbVitesse > 1 ? "s" : "");
	}


}
