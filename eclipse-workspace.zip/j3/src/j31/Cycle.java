package j31;

import java.time.LocalDate;

public abstract class Cycle implements Louable {

	public String type;
	public String marque;
	public String modele;
	public LocalDate dateAch;
	public String tarifs;
	public boolean loue;
	
	public Cycle(String type,String marque,String modele,LocalDate dateAch) {
		this.type = type;
		this.marque = marque;
		this.modele = modele;
		this.dateAch = dateAch;
		this.loue   = false;
		
	}
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getMarque() {
		return marque;
	}
	public void setMarque(String marque) {
		this.marque = marque;
	}
	public String getModele() {
		return modele;
	}
	public void setModele(String modele) {
		this.modele = modele;
	}
	public LocalDate getDateAch() {
		return dateAch;
	}
	public void setDateAch(LocalDate dateAch) {
		this.dateAch = dateAch;
	}
	public String getTarifs() {
		return tarifs;
	}
	public void setTarifs(String tarifs) {
		this.tarifs = tarifs;
	}

	public abstract double getTarifLocationHeure();

	public int age() {
		return dateAch.until(LocalDate.now()).getYears();
	}
    
	@Override
	public boolean isLoue() {
		return loue;
	}

	@Override
	public void setLoue(boolean b) {
		this.loue = b;
	}

	public String toString() {
		int age = this.age();
		return String.format("%s %s %s (%dan%s) %s", this.getClass().getSimpleName(),  this.marque, this.modele, age,
				age > 1 ? "s" : "" , "Lou� ? " + isLoue() );
	}
	
}
