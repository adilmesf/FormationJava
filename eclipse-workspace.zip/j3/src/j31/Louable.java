package j31;

public interface Louable {
	
	boolean isLoue();
	void setLoue(boolean b);
}
