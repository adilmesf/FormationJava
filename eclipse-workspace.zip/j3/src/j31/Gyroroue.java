package j31;

import java.time.LocalDate;

public class Gyroroue extends Cycle {

	private int autonomie;
	private final int tailleMinCm;
	
	public Gyroroue(String type, String marque, String modele, LocalDate dateAch, int autonomie, int tailleMinCm) {
		super(type, marque, modele, dateAch);
		this.autonomie = autonomie;
		this.tailleMinCm = tailleMinCm;
		
	}

	public int getautonomie() {
		return autonomie;
	}

	public void setautonomie(int autonomie) {
		this.autonomie = autonomie;
	}

	@Override
	public double getTarifLocationHeure() {
		return 29.9;
	}

	@Override
	public String toString() {
		return String.format("%s [%dm%d min]", super.toString(), this.tailleMinCm / 100, this.tailleMinCm % 100);
	}

	
}
