package j31;

import java.util.ArrayList;
import java.util.List;

public class LocationService {

	private static List<Louable> stockCycle;
	//private static int vIndex;
	
	static {
		stockCycle = new ArrayList<Louable>();
	}
	
	public static void ajouter(Louable cycle) {
		stockCycle.add(cycle);
	}

	public static void ajouterTout(List<? extends Louable> cycle) {
		stockCycle.addAll(cycle);
	}
	
	public static void louerCycle(Louable articleLouable) throws Exception {
		//vIndex = stockCycle.indexOf(articleLouable);
		/*if ((vIndex > -1) && (stockCycle.get(vIndex).isLoue() == false)) {
			stockCycle.get(vIndex).setLoue(true);
		} else {
			throw new Exception("D�j� Lou�");
		}*/
		if (articleLouable.isLoue()) {
			throw new Exception("D�j� Lou�");
		} else {
			articleLouable.setLoue(true);
		}

	}
	
	public static void afficherStock() {
		for(int i = 0 ; i < stockCycle.size(); i++)
			System.out.println(stockCycle.get(i));

	}
	
	public synchronized static void libererCycle(Louable articleLouable) throws Exception {
		if (!articleLouable.isLoue()) {
			throw new Exception ("Ce cycle n'est pas en location");
		}
		articleLouable.setLoue(false);
	}
	
	
}
