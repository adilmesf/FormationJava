package exemplesTri;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		//List<String> cars = Arrays.asList("Porsche 911", "Ferrari 458", "Lamborghini Urus");
		List<String> cars = List.of("Porsche 911", "Ferrari 458", "Lamborghini Urus");
		List<String> streamed = cars.stream()
					.map(e -> {
						e = e.toUpperCase();
						e = e.substring(1);
						return e;
					})
					.filter(e -> e.length() > 2).sorted().collect(Collectors.toList());
		System.out.println(streamed);
		//cars.forEach( c -> System.out.println(c));
	}

}
